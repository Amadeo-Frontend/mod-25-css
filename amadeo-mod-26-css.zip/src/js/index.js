import '../scss/styles.scss'
/*import imageLogo from '../assets/images/logo-w.png'

const elemRoot = document.getElementById('root')
elemRoot.classList.add('container')

const elemImageBuilding = new Image()
elemImageBuilding.src = imageLogo

const elemImageNotebook = new Image()
elemImageNotebook.src = imageNotebook

document.querySelector('#logo')
    .appendChild(elemImageBuilding)

document.querySelector('#notebook')
    .appendChild(elemImageNotebook)*/